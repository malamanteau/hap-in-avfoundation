#import <Foundation/Foundation.h>
#import <CoreMedia/CoreMedia.h>



extern CMMemoryPoolRef		_HIAVFMemPool;
extern CFAllocatorRef		_HIAVFMemPoolAllocator;
extern OSSpinLock			_HIAVFMemPoolLock;



